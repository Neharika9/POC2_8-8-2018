﻿using Microsoft.Practices.Unity;
using EmployeeTracker.Repositories;
using EmployeeTracker.Models;
using System.Collections.Generic;
using System.Linq;
using Unity.Attributes;

namespace EmployeeTracker.Repositories
{
    //The EmployeeInfo Repository Class. This is used to 
    //Isolate the EntitiFtamework based Data Access Layer from
    //the MVC Controller class
    public class EmployeeInfoRepository : IRepository<Employee,int>
    {

        EmployeeTrackerEntities contextt = new EmployeeTrackerEntities();
        

        public IEnumerable<Employee> Get()
        {
          
            return contextt.Employees.ToList();
        }
		//find employee by id
        public Employee Get(int id)
        {
		    var c = (from r in contextt.Employees where r.EmpId == id select r).FirstOrDefault();
            return c;
            //return contextt.Employees.Find(id);
        }

        public int Add(Employee entity)
        {
            contextt.Employees.Add(entity);
            contextt.SaveChanges();
         
            int id = entity.EmpId;
            return id;
    }
    // Edit a Employee
    public void Edit(Employee entity)
      {
         contextt.Entry(entity).State = System.Data.Entity.EntityState.Modified;
         contextt.SaveChanges();
      }

        public void Remove(Employee entity)
        {
            var obj = contextt.Employees.Find(entity.EmpId);
            contextt.Employees.Remove(obj);
            contextt.SaveChanges();
        }
		
    }
}