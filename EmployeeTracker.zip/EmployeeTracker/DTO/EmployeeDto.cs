﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EmployeeTracker.Models;

namespace EmployeeTracker.DTO
{
    public class EmployeeDto
    {
       
       
        public int EmpId { get; set; }
        public int EmpdetailId { get; set; }
        public string EmpName { get; set; }
        public string EmpAddress { get; set; }
        public Nullable<int> EmpContact { get; set; }
        public string EmpEmailId { get; set; }
        public string EmpDepartment { get; set; }
        public int DetailId { get; set; }
        public string Qualification { get; set; }
        public string Training { get; set; }
        public string ManagerName { get; set; }
        public string ManagerAddress { get; set; }
        public Nullable<int> ManagerContact { get; set; }
        public string ManagerDepartment { get; set; }

    }
}