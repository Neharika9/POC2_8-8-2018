﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmployeeTracker.BusinessLayer;
using EmployeeTracker.DTO;
using System.Web.Http.Description;
using EmployeeTracker.Models;
using EmployeeTracker.Exceptions;


namespace EmployeeTracker.Controllers
{

    public class EmployeeController : ApiController
    {
        public EmployeeService _employeeService;
        public EmployeeDetailService _employeeDetailService;
        public EmployeeController()
        {
            _employeeService = new EmployeeService();
            _employeeDetailService = new EmployeeDetailService();
        }


        Employee db = new Employee();
        EmployeeDetail dbEmployeeDetail = new EmployeeDetail();
        // GET api/order
        [CustomExceptions]
        public HttpResponseMessage Get()
        {
            var emp = _employeeService.Get();
            if (emp != null)
                return Request.CreateResponse(HttpStatusCode.OK, emp);
            else return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No orders found");
        }

        // POST: api/Employees
        //public IHttpActionResult PostEmployee(EmployeeDto employee)
        //{
        ///var Emp = _employeeService.Get(employee.EmpId);
        //if (!ModelState.IsValid)
        //{
        //return BadRequest(ModelState);
        //}


        // db.Employees.Add(employee);

        //try
        //{

        //  await db.SaveChangesAsync();

        //}
        ////catch (DbUpdateException)
        ////{
        ////    if (EmployeeExists(employee.Id))
        ////    {
        ////        return Conflict();
        ////    }
        ////    else
        ////    {
        ////        throw;
        ////    }
        ////}

        //return CreatedAtRoute("DefaultApi", new { }, employee);
        //}


        //// PUT: api/Employees/5
        // we can perform edit employee method
        [ResponseType(typeof(void))]
        [CustomExceptions]

        public IHttpActionResult PutEmployee(int id, EmployeeDto empl)
        {
            Employee db = new Employee();
            EmployeeDetail dbEmployeeDetail = new EmployeeDetail();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != empl.EmpId)
            {
                return BadRequest();
            }
            // Calling the Reopsitory employee edit method
            db.EmpName = empl.EmpName;
            db.EmpId = empl.EmpId;
            db.EmpDepartment = empl.EmpDepartment;
            db.EmpContact = empl.EmpContact;
            db.EmpAddress = empl.EmpAddress;
            db.EmpEmailId = empl.EmpEmailId;
            _employeeService.Edit(db);

            return StatusCode(HttpStatusCode.NoContent);
        }

        //// POST: api/Employees/
        // we can perform add employee method
        [CustomExceptions]
        [ResponseType(typeof(EmployeeDto))]
        public IHttpActionResult PostEmployee(EmployeeDto empl)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            // Calling the Reopsitory project AddEmployee method
            db.EmpName = empl.EmpName;
            db.EmpId = empl.EmpId;
            db.EmpDepartment = empl.EmpDepartment;
            db.EmpContact = empl.EmpContact;
            db.EmpAddress = empl.EmpAddress;
            db.EmpEmailId = empl.EmpEmailId;
            dbEmployeeDetail.Qualification = empl.Qualification;
            dbEmployeeDetail.Training = empl.Training;

            int empId = _employeeService.Add(db);
            dbEmployeeDetail.EmpId = empId;
            // _employeeDetailService.Add(dbEmployeeDetail);

            // return CreatedAtRoute("DefaultApi", new { id = empl.EmpId }, empl);
            //   dbEmployeeDetail.DetailId = 0;
            _employeeDetailService.Add(dbEmployeeDetail);
        //}
            
               // throw new ProcessException("this is custom error");
        //string err = ex.stacktrace.tostring();

    //}
                //if(empId != null)
                //{
                //    throw new ProcessException("Test error");
                //}

                return CreatedAtRoute("DefaultApi", new { id = empl.EmpId }, empl);
           
        }

        //// DELETE: api/Books//5
        // we can perform delete employee method
        [CustomExceptions]

        [ResponseType(typeof(EmployeeDto))]

        public IHttpActionResult DeleteEmployee(int id)
        {
            db = _employeeService.Get(id);
            if (db == null)
            {
                return NotFound();
            }
            // Calling the Reopsitory project RemoveEmployee method
            _employeeService.Remove(db);  

            return Ok(db);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
               // _employeeService.Dispose();
            }
            base.Dispose(disposing);
        }


    }
}
