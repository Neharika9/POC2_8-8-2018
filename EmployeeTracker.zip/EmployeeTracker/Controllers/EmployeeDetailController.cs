using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using EmployeeTracker.BusinessLayer;
using EmployeeTracker.DTO;
using EmployeeTracker.Models;

namespace EmployeeTracker.Controllers
{
    public class EmployeeDetailController : ApiController
    {
        public EmployeeDetailService _employeeService;
        public EmployeeDetailController()
        {
            _employeeService = new EmployeeDetailService();
           
        }
        EmployeeDetail dbDetail = new EmployeeDetail();
        //�GET api/order
��������public HttpResponseMessage Get()
        {
            var emp = _employeeService.Get();
            if (emp != null)
                return Request.CreateResponse(HttpStatusCode.OK, emp);
            else return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No orders found");
        }

    // POST: api/Employees
    //public IHttpActionResult PostEmployee(EmployeeDto employee)
    //{
    ///var Emp = _employeeService.Get(employee.EmpId);
    //if (!ModelState.IsValid)
    //{
    //return BadRequest(ModelState);
    //}


    // db.Employees.Add(employee);

    //try
    //{

    //  await db.SaveChangesAsync();

    //}
    ////catch (DbUpdateException)
    ////{
    ////    if (EmployeeExists(employee.Id))
    ////    {
    ////        return Conflict();
    ////    }
    ////    else
    ////    {
    ////        throw;
    ////    }
    ////}

    //return CreatedAtRoute("DefaultApi", new { }, employee);
    //}


    //// PUT: api/EmployeeDetails/5
    // we can perform edit employee details method
    [ResponseType(typeof(void))]        
        public IHttpActionResult PutEmployee(int id, EmployeeDto empl)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != empl.EmpId)
            {
                return BadRequest();
            }
            dbDetail.Qualification = empl.Qualification;
            dbDetail.Training = empl.Training;
            // Calling the Reopsitory employee edit method
            _employeeService.Edit(dbDetail);

            return StatusCode(HttpStatusCode.NoContent);
        }
		 // GET: api/EmployeeDetails/3
        // we can fetch data as XML file via http://localhost:13793/api/EmployeeDetail/{id} URI
        //[ResponseType(typeof(EmployeeDto))]
        //public IHttpActionResult GetEmployeeWithDetailsById(int id)
        //{
        //    // Calling the Reopsitory project Get method
        //    dbDetail = _employeeService.Get(id);
        //    if (dbDetail == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(dbDetail);
        //}

        //// POST: api/Employees/
        // we can perform add employee method
        [ResponseType(typeof(EmployeeDto))]
        public IHttpActionResult PostEmployee(EmployeeDto empl)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            // Calling the Reopsitory project AddEmployee method
            dbDetail.EmpId = empl.EmpId;
            dbDetail.Qualification = empl.Qualification;
            dbDetail.Training = empl.Training;
            _employeeService.Add(dbDetail); 

            return CreatedAtRoute("DefaultApi", new { id = empl.EmpId }, empl);
        }

        //// DELETE: api/Books//5
        // we can perform delete employee method
        [ResponseType(typeof(EmployeeDto))]
        public IHttpActionResult DeleteEmployee(int id)
        {
            dbDetail = _employeeService.Get(id);
            if (dbDetail == null)
            {
                return NotFound();
            }
            // Calling the Reopsitory project RemoveEmployee method
            _employeeService.Remove(dbDetail);  

            return Ok(dbDetail);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
               // _employeeService.Dispose();
            }
            base.Dispose(disposing);
        }


    }
}
