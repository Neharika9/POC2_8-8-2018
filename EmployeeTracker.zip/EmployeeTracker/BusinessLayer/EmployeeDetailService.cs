using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EmployeeTracker.Models;
using EmployeeTracker.Repositories;

namespace EmployeeTracker.BusinessLayer
{
    public class EmployeeDetailService
    {
        public EmployeeDetailRepository _employeeDetailRepository;

        public static List<EmployeeDetail> _empList;��//complete list of employees
�������

        public EmployeeDetailService()
        {
            _employeeDetailRepository = new EmployeeDetailRepository();
            
        }


        ///�<summary>
��������///�Gets all orders with names of employee.
��������///�</summary>
��������///�<returns></returns>
��������public IEnumerable<EmployeeDetail> Get()
        {
            if (_empList == null)
            {
                _empList = _employeeDetailRepository.Get().ToList();

            }
            return _empList;
        }
        public EmployeeDetail Get(int id)
        {

            return _employeeDetailRepository.Get(id);

        }
        public int Add(EmployeeDetail entity)
        {
            return _employeeDetailRepository.Add(entity);
        }
		 // Edit a Employee
      public void Edit(EmployeeDetail entity)
      {
         _employeeDetailRepository.Edit(entity);
      }

       //deleteing employee
	   public void Remove(EmployeeDetail entity)
        {
             _employeeDetailRepository.Remove(entity);
        }

    }
}