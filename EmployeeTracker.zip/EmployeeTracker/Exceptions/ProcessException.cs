﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeTracker.Exceptions
{
    public class ProcessException:Exception
    {
        public ProcessException(string message)
: base(message)
        { 
            
        }
        public ProcessException(string message, Exception ex) : base(message, ex)
        { }
    }
}